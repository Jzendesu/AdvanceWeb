import { initializeApp } from 'firebase/app'
import { getAuth } from 'firebase/auth'

const firebaseConfig = {
  apiKey: "AIzaSyBo3N_gXX5sfEjMlfu9SasgjXbybNdVark",
  authDomain: "election-ce4fa.firebaseapp.com",
  projectId: "election-ce4fa",
  storageBucket: "election-ce4fa.appspot.com",
  messagingSenderId: "95391896959",
  appId: "1:95391896959:web:ee3471445957d529a7b64a"
};

const app = initializeApp(firebaseConfig)

export const auth = getAuth(app)
